def num_to_words(n):
    # Helper functions for single, teen, and tens digits
    def one_to_nineteen(n):
        words = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
                 "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", 
                 "eighteen", "nineteen"]
        return words[n]

    def tens(n):
        words = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]
        return words[n]

    # Helper function for converting a number less than 1000
    def convert_chunk(n):
        if n == 0:
            return ""
        elif n < 20:
            return one_to_nineteen(n)
        elif n < 100:
            return tens(n // 10) + (" " + one_to_nineteen(n % 10) if (n % 10) != 0 else "")
        else:
            return one_to_nineteen(n // 100) + " hundred" + (" " + convert_chunk(n % 100) if (n % 100) != 0 else "")

    # Process large numbers in chunks (thousand, million, billion)
    if n == 0:
        return "zero"

    billion = n // 1000000000
    million = (n // 1000000) % 1000
    thousand = (n // 1000) % 1000
    remainder = n % 1000

    result = ""
    if billion > 0:
        result += convert_chunk(billion) + " billion"
    if million > 0:
        result += (" " if result else "") + convert_chunk(million) + " million"
    if thousand > 0:
        result += (" " if result else "") + convert_chunk(thousand) + " thousand"
    if remainder > 0:
        result += (" " if result else "") + convert_chunk(remainder)

    return result.strip()

# Test cases
print(num_to_words(1000))   # Output: 'one thousand'
print(num_to_words(4003))   # Output: 'four thousand three'